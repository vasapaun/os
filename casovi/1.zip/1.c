#include <stdio.h>
#include <stdlib.h>

#define check_error(expr,userMsg) \
	do { \
		if (!(expr)) { \
			perror(userMsg); \
			exit(EXIT_FAILURE) ; \
		} \
	} while(0)
	
#define START_CAP	(32)

typedef struct {
	int* niz;
	int capacity;
	int size;
} DinamickiNiz_t;

void inicijalizujNiz(DinamickiNiz_t* dt) {
	
	dt->capacity = START_CAP;
	dt->size = 0;
	dt->niz = malloc(sizeof(int)*START_CAP);
	/*
	if (dt->niz == NULL) {
		fprintf(stderr, "Greska pri alokaciji\n");
		exit(EXIT_FAILURE);
	}
	*/
	check_error(dt->niz != NULL, "greska [ri alokacija");
	
}

void deinicijalizujNiz(DinamickiNiz_t* dt) {

	free(dt->niz);
	dt->niz = NULL;
	dt->size = 0;
	dt->capacity = START_CAP;
}

void dodajUNiz(DinamickiNiz_t* dt, int x) {

	if (dt->size == dt->capacity) {
		
		int* tmp = realloc(dt->niz,
			dt->capacity*2*sizeof(int));
		check_error(tmp != NULL, "realloc");
		dt->capacity *= 2;	
		dt->niz = tmp;
	}
	
	dt->niz[dt->size] = x;
	dt->size++;
}

void stampajNiz(DinamickiNiz_t* dt) {

	for (int i = 0; i < dt->size; i++) {
		printf("%d ", dt->niz[i]);
	}	
}

int main(int argc, char** argv) {

	check_error(argc == 2, "args");
	
	int n = atoi(argv[1]);
	DinamickiNiz_t dt;
	
	inicijalizujNiz(&dt);
	for (int i = 0; i < n; i++) {
	
		dodajUNiz(&dt, rand());
	}
	
	stampajNiz(&dt);
	
	deinicijalizujNiz(&dt);
	
	exit(EXIT_SUCCESS);
}

