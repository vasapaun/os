#include <stdio.h>
#include <stdlib.h>

#define MAX_SIZE (256)

int main() {

	char rec[MAX_SIZE];
	char c;
	int i = 0;
	//rec[0] = 0;
	
	//scanf("%s", rec);
	while ((c = getchar()) != EOF) {
	
		rec[i] = c;
		i++;
	}
	rec[i] = 0;
	
	printf("%s\n", rec);
	
	exit(EXIT_SUCCESS);	
}
