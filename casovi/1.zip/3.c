#include <stdio.h>
#include <stdlib.h>

#define checkError(expr,userMsg) \
	do {\
		if (!(expr)) { \
			perror(userMsg);\
			exit(EXIT_FAILURE);\
		}\
	} while (0)
	
int main(int argc, char** argv) {
	
	checkError(argc == 2, "args");
	
	FILE* f = fopen(argv[1], "r");
	checkError(f != NULL, "fopen");
	char rec[256];
	
	while (fscanf(f, "%s", rec) == 1) {
	
		printf("%s ", rec);
	}
	
	checkError(feof(f), "file error");
	
	fclose(f);
	
	exit(EXIT_SUCCESS);
}
