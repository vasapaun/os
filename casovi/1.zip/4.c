#include <stdio.h>
#include <stdlib.h>

int** alocirajMatricu(int m, int n) {
	
	int **mat = NULL;
	
	mat = malloc(sizeof(int*)*m);
	if (mat == NULL) {
		fprintf(stderr,"Error: %s\nLine: %d\nFile: %s\nFunction: %s\n",
		"malloc", __LINE__, __FILE__,
		__func__);
		exit(EXIT_FAILURE);
	}
	for (int i = 0; i < m; i++) {
		
		mat[i] = malloc(sizeof(int)*n);
		if (mat[i] == NULL)
			exit(EXIT_FAILURE);
	}
	
	return mat;
}

void dealocirajMatricu(int** mat, int m, int n) {
	
	for (int i = 0; i < m; i++)
		free(mat[i]);
		
	free(mat);
}

int main() {

	int** mat = NULL;
	int m, n;
	
	scanf("%d%d", &m, &n);
	
	mat = alocirajMatricu(m, n);
	
	// nesto sa matricom
	
	dealocirajMatricu(mat, m, n);
	
	exit(EXIT_SUCCESS);
}
