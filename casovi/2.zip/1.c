#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>

#include <stdio.h>
#include <stdlib.h>

#define checkError(expr,userMsg) \
    do {\
        if (!(expr)) {\
            perror(userMsg); \
            exit(EXIT_FAILURE);\
        }\
    } while (0)

// nas fopen treba da vrati fajl deskriptor fajla
int my_fopen(char* fileName, char* mode){

    mode_t pravaPristupa = 0777; // zelja
    int flags = 0;

    switch (mode[0]) {
        case 'r':
            flags |= (mode[1] == '+') ? O_RDWR : O_RDONLY;
            break;
        case 'w':
            flags |= (mode[1] == '+') ? O_RDWR : O_WRONLY;
            flags |= O_TRUNC; // obrisi sadrzaj fajl
            flags |= O_CREAT; // kreiraj fajl
            break;
        case 'a':
            flags |= (mode[1] == '+') ? O_RDWR : O_WRONLY;
            flags |= O_APPEND; // nadovezi sadrzaj
            flags |= O_CREAT;  // kreiraj fajl
            break;
        default:
            return -1;
    }

    int fd = open(fileName, flags, pravaPristupa);

    return fd;
}

// ./a.out fileName flags
int main(int argc, char** argv) {

    checkError(argc == 3, "args");

    int fd = my_fopen(argv[1], argv[2]);
    checkError(fd != -1, "open");

    close(fd);

    exit(EXIT_SUCCESS);
}