#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>

#include <stdio.h>
#include <stdlib.h>

#include <errno.h>

#define checkError(expr,userMsg) \
    do {\
        if (!(expr)) {\
            perror(userMsg); \
            exit(EXIT_FAILURE);\
        }\
    } while (0)
// program kreira direktorijum
// ./a.out naziv pravaPristupa
// ./a.out dirA 0755
int main(int argc, char** argv) {

    checkError(argc == 3, "args");

    int pravaPristupa = strtol(argv[2], NULL, 8);

    int retVal = mkdir(argv[1], pravaPristupa);
    if (retVal == -1) {
        if (errno != EEXIST) {
            checkError(retVal != -1, "mkdir");
        }
    }

    exit(EXIT_SUCCESS);
}