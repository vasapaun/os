#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>

#include <stdio.h>
#include <stdlib.h>

#define checkError(expr,userMsg) \
    do {\
        if (!(expr)) {\
            perror(userMsg); \
            exit(EXIT_FAILURE);\
        }\
    } while (0)

#define BUF_SIZE    (8096)

// ./cat filePath
int main(int argc, char** argv) {

    checkError(argc == 2, "args");

    int fd = open(argv[1], O_RDONLY);
    checkError(fd != -1, "open");

    char buffer[BUF_SIZE];
    int readBytes = 0;
    while ((readBytes = read(fd, buffer, BUF_SIZE)) > 0) {

        checkError(write(STDOUT_FILENO, buffer, readBytes) != -1, "write");
    }

    checkError(readBytes != -1, "read");

    close(fd);

    exit(EXIT_SUCCESS);
}