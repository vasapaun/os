#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>

#include <stdio.h>
#include <stdlib.h>

#define checkError(expr,userMsg) \
    do {\
        if (!(expr)) {\
            perror(userMsg); \
            exit(EXIT_FAILURE);\
        }\
    } while (0)

#define BUF_SIZE (8096)

// ./cp srcFile destFile
int main(int argc, char** argv) {

    checkError(argc == 3, "args");

    int srcFd = open(argv[1], O_RDONLY);
    checkError(srcFd != -1, "src open");

    int destFd = open(argv[2], O_WRONLY | O_CREAT | O_TRUNC,  0644);
    checkError(destFd != -1, "dest open");

    char buffer[BUF_SIZE];
    int readBytes = 0;
    while ((readBytes = read(srcFd, buffer, BUF_SIZE)) > 0) {

        checkError(write(destFd, buffer, readBytes) != -1, "write");
    }

    checkError(readBytes != -1, "read");

    close(srcFd);
    close(destFd);

    exit(EXIT_SUCCESS);
}