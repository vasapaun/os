#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define checkError(expr,userMsg) \
    do {\
        if (!(expr)) {\
            perror(userMsg); \
            exit(EXIT_FAILURE);\
        }\
    } while (0)
// ./rm -[f|d] fPath
int main(int argc, char** argv) {

    checkError(argc == 3, "args");

    if (strcmp(argv[1], "-f") == 0) {

        checkError(unlink(argv[2]) != -1, "unlink");
    }
    else if (strcmp(argv[1], "-d") == 0) {
        checkError(rmdir(argv[2]) != -1, "rmdir");
    }
    else {
        checkError(0, "option");
    }


    exit(EXIT_SUCCESS);
}