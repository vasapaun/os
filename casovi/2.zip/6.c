#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>

#include <stdio.h>
#include <stdlib.h>

#define checkError(expr,userMsg) \
    do {\
        if (!(expr)) {\
            perror(userMsg); \
            exit(EXIT_FAILURE);\
        }\
    } while (0)

// ./a.out fPath
int main(int argc, char** argv) {

    checkError(argc == 2, "args");

    int fd = open(argv[1], O_RDONLY);
    checkError(fd != -1, "open");

    off_t ofset = lseek(fd, 0, SEEK_END);
    checkError(ofset != (off_t)-1, "lseek");

    printf("File size pogresno: %dB\n", (int)ofset);

    close(fd);

    exit(EXIT_SUCCESS);
}